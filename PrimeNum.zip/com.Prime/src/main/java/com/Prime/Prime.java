package com.Prime;

import java.util.Scanner;

class Prime implements Runnable {
	
	long j, c;

	Prime() {
		super();
		c = 0;
	}

	boolean checkPrime(long i) {
		for (j = 2; j <= i; j++) {
			if (i % j == 0)
				break;
		}
		if (j == i) {
			return true;
		}
		return false;

	}

	public void run() {

		Scanner s = new Scanner(System.in);

		long n = s.nextLong();

		for (long i = 0; i <= n; i++) {

			if (checkPrime(i)) {
				c++;
				System.out.println(c + "th" + " Prime no: = " + i);
			}
		}
		
		s.close();
	}

	public static void main(String[] args) {
		
		Thread ct = Thread.currentThread();
		
		System.out.println("Main thread name : " + ct.getName());
		
		Prime p = new Prime();
		
		System.out.println("Enter a number");
		

		Thread prime = new Thread(p);

		prime.start();
		System.out.println("Thread " + prime.getName() + " started.");
	}

}
