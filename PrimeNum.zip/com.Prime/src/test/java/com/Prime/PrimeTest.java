package com.Prime;


import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class PrimeTest {
	
	Prime obj=new Prime();

	@Test
	public void ifPrimeNumberGivenThenShouldReturnTrue()
	{
		assertEquals(true,obj.checkPrime(23));
	}
	
	@Test
	public void ifNotPrimeNumberGivenThenShouldReturnFalse()
	{
		assertEquals(false,obj.checkPrime(25));
	}
}